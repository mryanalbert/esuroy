<?php require_once './assets/php/header.php'; ?>
<main>
  <div class="container-fluid">
    <h1>Products</h1>
  </div>
</main>
<?php require_once './assets/php/footer.php'; ?>
<script>
  $(document).ready(function() {

  })
</script>