---
title: Ban
categories:
  - Real World
tags:
  - no
  - "not allowed"
added: 1.11.0
---
