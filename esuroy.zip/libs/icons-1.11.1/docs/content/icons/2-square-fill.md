---
title: 2 square fill
categories:
  - Shapes
tags:
  - number
  - numeral
---
