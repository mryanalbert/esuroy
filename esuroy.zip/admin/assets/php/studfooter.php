<footer></footer>
<script src="./libs/jquery.min.js"></script>
<script src="./libs/bootstrap.bundle.min.js"></script>
<script src="./libs/sweetalert2.all.min.js"></script>
<script src="./libs/DataTables/datatables.min.js"></script>
<script src="./libs/DataTables/FixedHeader-3.4.0/js/dataTables.fixedHeader.js"></script>
<script src="./libs/chart.js"></script>
<script src="./libs/summernote/summernote-lite.js"></script>